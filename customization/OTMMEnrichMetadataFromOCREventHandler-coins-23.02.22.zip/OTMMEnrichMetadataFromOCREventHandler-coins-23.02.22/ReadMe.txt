This customization will deploy a custom Jar, OTMMEnrichMetadataFromOCREventHandler-coins-23.02.22.jar.

This add-on search for coin's year an value in the OCR text found in the picture.

This customization will work for both Jboss and Tomee in Windows as well as in Linux environment.